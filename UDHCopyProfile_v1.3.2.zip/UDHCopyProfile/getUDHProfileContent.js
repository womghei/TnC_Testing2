//make network request to retrieve profile
//GET https://my.tealiumiq.com/urest/datacloud/services-mreddin/main/profile?utk=[utk]
//Header Cookie JSESSIONID=[JSESSIONID];
var utk = localStorage.getItem('utk');
var xhr = new XMLHttpRequest();

//calling popup.js has already defined fromAccountProfile for us, but JSON stringified
whichAccountProfile = JSON.parse(whichAccountProfile);
//12Apr2019 - used to be
//xhr.open("GET", "https://my.tealiumiq.com/urest/datacloud/" + whichAccountProfile.account + "/" + whichAccountProfile.profile + "/profile?utk="+utk, false);
xhr.open("GET", "https://" + whichAccountProfile.host + "/urest/datacloud/" + whichAccountProfile.account + "/" + whichAccountProfile.profile + "/profile?utk="+utk, false);
xhr.send();

//this will return the result to the calling script popup.js
xhr.responseText;
