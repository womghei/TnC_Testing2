//12Apr2019 - allow for qa - previously '^https://my\.tealiumiq\.com/datacloud/[^/]+/\\?account=[^&]+&profile=[^&]+'
chrome.runtime.onInstalled.addListener(function() {
  chrome.declarativeContent.onPageChanged.removeRules(undefined, function() {
    chrome.declarativeContent.onPageChanged.addRules([{
      conditions: [new chrome.declarativeContent.PageStateMatcher({
        pageUrl: {urlMatches:'^https://([^/-]+-)?(my|sso)\\.tealiumiq\\.com/datacloud/[^/]+/\\?account=[^&]+&profile=[^&]+'}
      })
      ],
          actions: [new chrome.declarativeContent.ShowPageAction()]
    }]);
  });
});

chrome.extension.onMessage.addListener(
    function(request, sender, sendResponse){
        if(request.msg == "replaceProfile") replaceContent(request.toAccountProfile, request.content);
    }
);

var replaceContent = function(toAccountProfile, content){
  var timesReplaced = 0;
  chrome.debugger.getTargets((targets) => {
    //var found = targets.filter(target => target.title == "Tealium - Universal Data Hub");
    //var found = targets.filter(target => target.title == "UDH - services-mreddin");
    //12Apr2019 - was previously
    //var found = targets.filter(target => target.url.indexOf("https://my.tealiumiq.com/datacloud/en-US/?account="+toAccountProfile.account+"&profile="+toAccountProfile.profile) == 0);
    var RE = new RegExp("https://([^/-]+-)?(my|sso)\\.tealiumiq\\.com/datacloud/[^/]+/\\?account="+toAccountProfile.account+"&profile="+toAccountProfile.profile);
    var found = targets.filter(target => RE.test(target.url) == true);
    if (found.length != 1){
      chrome.extension.sendMessage({ msg: "errorFromBackground", messageText:"Please check again that you only have one UDH window open, in any Chrome instance" });
      return false;
    }
    let target = found[0];
    let debuggee = { tabId : target.tabId };

    //07Feb2018 - previously listener and addListener was after attached function and attach, below
    //AB said this may have possibly been the cause of some timing issues
    window.theListener = (source, method, params) => {
      let headers = params.responseHeaders;
      if (method === "Network.requestIntercepted") {
        f(debuggee, params, target.tabId);
      }
    };

    chrome.debugger.onEvent.addListener(window.theListener);

    var attachedFunction = () => {
      chrome.debugger.sendCommand(debuggee, "Network.setRequestInterception", {
        patterns: [ {
          interceptionStage: "HeadersReceived",
          urlPattern: "*/urest/datacloud/"+toAccountProfile.account+"/"+toAccountProfile.profile+"/profile*"
        } ]
      },function(result){console.log(result);});
    };

    chrome.debugger.attach(debuggee, "1.2", attachedFunction);


    chrome.tabs.executeScript(target.tabId, { code: 'window.location.reload();' });
  });

  function f(debuggee, params, theTabId) {
      chrome.debugger.sendCommand(debuggee, "Network.getResponseBodyForInterception",
        { interceptionId: params.interceptionId },
        function ({base64Encoded, body}) {
          let bodyData = base64Encoded ? atob(body) : body;

          function lengthInUtf8Bytes(str) {
            // Matches only the 10.. bytes that are non-initial characters in a multi-byte sequence.
            var m = encodeURIComponent(str).match(/%[89ABab]/g);
            return str.length + (m ? m.length : 0);
          }

          const newHeaders = [
            'HTTP/1.1 200 OK',
            'Date: ' + (new Date()).toUTCString(),
            'Connection: closed',
            'Content-Length: ' + content.length,
            'Content-Type: text/javascript'
          ];

          chrome.debugger.sendCommand(debuggee, "Network.continueInterceptedRequest", {
            interceptionId: params.interceptionId,
            rawResponse: btoa(unescape(encodeURIComponent(newHeaders.join('\r\n') + '\r\n\r\n' + content)))
          }, function () {
              console.log('done');
              chrome.debugger.onEvent.removeListener(window.theListener);
              delete window.theListener
              chrome.debugger.detach(debuggee);
              //we want to mark profile as dirty.  However, UDH AS Core will call setDirty again after we do, because a new profile has has been
              //loaded and it wishes to mark it as not dirty.  So we ignore its first call by overriding the function
              chrome.tabs.executeScript(theTabId, { code: 'var s = document.createElement("script"); s.innerText="var interval = setInterval(function() {if (gApp && gApp.utils && jQuery && jQuery(\'#saveProfileButton\').length == 1 && typeof(gApp.utils.setDirty == \'function\')) {gApp.utils.setDirty(!0);var original = gApp.utils.setDirty;gApp.utils.setDirty = function(e) {gApp.setDirtyCounter = gApp.setDirtyCounter || 0;gApp.setDirtyCounter++;if (gApp.setDirtyCounter > 1) {original(e);}};clearInterval(interval);}}, 1000);"; document.body.appendChild(s);' });
          });
        });
  }
};
